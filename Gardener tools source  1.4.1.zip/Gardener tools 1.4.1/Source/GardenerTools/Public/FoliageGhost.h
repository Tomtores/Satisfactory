

#pragma once

#include "CoreMinimal.h"
#include "Engine/StaticMeshActor.h"

#include <FactoryGame/Public/FGFoliageRemoval.h>
#include <FactoryGame/Public/FGFoliageRemovalSubsystem.h>

#include "FoliageGhost.generated.h"

/**
 * 
 */
UCLASS()
class GARDENERTOOLS_API AFoliageGhost : public AStaticMeshActor
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = GardenerToolkit)
	bool RemoveFromWorld(FString& log);

	void SetupData(TPair<FName, FName> removalActorIdentifier, FTransform transform, AFGFoliageRemovalSubsystem* FoliageSystem);

private:
	TPair<FName, FName> mRemovalActorIdentifier;
	FTransform mTransform;
	AFGFoliageRemovalSubsystem* mFoliageSystem;
};
