#include "URegrowCommand.h"

UClass* FoliageActorClass;
const int MaxBatchUndeletes = 1000;

static bool IsInRange(FTransform transform, FVector playerLocation, int range, FString& log, bool debug)
{
	FVector foliageLocation = transform.GetTranslation();

	float distance = FVector::Dist(playerLocation, foliageLocation);

	if (debug)
	{
		log += FString::Printf(TEXT("Distance %d\n"), (int)distance);
	}

	return distance <= range;
}

FString URegrowCommand::InitializeFoliageTypes(UClass* foliageActorClassInput)
{
	FoliageActorClass = foliageActorClassInput;
		
	return FString("Cached foliage actor");
}

FString URegrowCommand::Regrow(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, bool debug, const UObject* WorldContextObject)
{
	if (!FoliageSystem)
	{
		return FString("Error! No subsystem");
	}
	if (!WorldContextObject)
	{
		return FString("Error, no World object!");
	}
	
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

	if (!World)
	{
		return FString("Failed to resolve World object!");
	}

	FString result;

	if (debug)
	{
		int countBefore = FoliageSystem->GetFoliageCountWithinRadius(playerLocation, range);

		result += FString::Printf(TEXT("Found %d total foliage items in the range.\n"), countBefore);
		// result += FString::Printf(TEXT("Known foliage types %d.\n"), FoliageTypes.Num());
	}

	int count = UndeleteFoliage_New(FoliageSystem, playerLocation, range, result, debug, World);

	result += FString::Printf(TEXT("Restored %d foliage items.\n"), count);

	if (debug)
	{
		int countAfter = FoliageSystem->GetFoliageCountWithinRadius(playerLocation, range);

		result += FString::Printf(TEXT("Found %d total foliage items in the range after operation"), countAfter);
	}

	return result;
}

int URegrowCommand::UndeleteFoliage_New(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, FString& log, bool debug, UWorld* World)
{
	int undeletedCount = 0;
	int processedDeletions = 0;
	//	
	//for (const TPair<FName, LevelFoliageData>& foliageperLevel : FoliageSystem->mLevelFoliageDataMap)	// data per level - Levelname:Data
	//{
	//	for (const TPair<FName, FoliageTypeData>& foliageTypeToDataMap : foliageperLevel.Value.foliageTypeToDataMap)	// data per foliage type - FoliageTypename:Data
	//	{
	//		for (FoliageInstanceData foliageInstance : foliageTypeToDataMap.Value.foliageInstances)	// list of all deleted foliage instances
	//		{
	//			// now we iterate through all the foliage instances available
	//			if (foliageInstance.isRemoved)
	//			{
	//				if (IsInRange(foliageInstance.transform, playerLocation, range, log, false))
	//				{
	//					if (debug)
	//					{
	//						log += FString::Printf(TEXT("NEW2 Found foliage in range with index %d \n"), foliageInstance.index);
	//					}

	//					AFoliageGhost* RespawnedFoliage = RespawnActor(foliageInstance.component.Get(), foliageInstance.transform.GetTranslation(), foliageInstance.transform, World, log, debug);

	//					if (RespawnedFoliage)
	//					{
	//						RespawnedFoliage->SetupData(TPair<FName, FName>(foliageperLevel.Key, foliageTypeToDataMap.Key), foliageInstance.transform, FoliageSystem);

	//						// perform the removal
	//						foliageInstance.isRemoved = false;
	//						foliageTypeToDataMap.Value.foliageRemoval->mRemovalLocations.Remove(foliageInstance.transform.GetTranslation());

	//						undeletedCount++;
	//					}
	//					else if (debug)
	//					{
	//						log.Append("Null actor for ");
	//						log.Append(foliageTypeToDataMap.Key.ToString());
	//						log.Append("\n");
	//					}

	//					processedDeletions++;
	//					if (processedDeletions >= MaxBatchUndeletes)
	//					{
	//						goto EXIT;
	//					}
	//				}
	//			}
	//		}
	//	}
	//}

//	EXIT:
	return undeletedCount;
}

AFoliageGhost* URegrowCommand::RespawnActor(UHierarchicalInstancedStaticMeshComponent* mesh, FVector location, FTransform transform, UWorld* World, FString& log, bool debug)
{
	FActorSpawnParameters parameters = FActorSpawnParameters();
	parameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	parameters.bNoFail = true;
	AFoliageGhost* RespawnedFoliage = World->SpawnActor<AFoliageGhost>(FoliageActorClass, location, transform.Rotator(), parameters);
	
	if (RespawnedFoliage)
		{
		    RespawnedFoliage->SetMobility(EComponentMobility::Stationary);
			UStaticMeshComponent* MeshComponent = RespawnedFoliage->GetStaticMeshComponent();
			if (MeshComponent)
			{
				MeshComponent->SetStaticMesh(mesh->GetStaticMesh());
			}
			else if (debug)
			{
				log += "Failed to get mesh component of spawned actor!!!\n";
			}
		}
		else if (debug)
		{
			log += "Actor spawn failed!!!\n";
		}
	
	return RespawnedFoliage;
}



