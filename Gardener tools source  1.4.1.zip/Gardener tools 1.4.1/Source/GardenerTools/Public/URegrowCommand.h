#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Containers/Map.h"
#include "Engine/World.h"
#include "Engine/EngineTypes.h"
#include "Engine/StaticMeshActor.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"

#include <FactoryGame/Public/FGFoliageRemovalSubsystem.h>

#include "FoliageGhost.h"
#include "URegrowCommand.generated.h"


UCLASS()
class GARDENERTOOLS_API URegrowCommand : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category=GardenerToolkit, meta = (WorldContext = "WorldContextObject"))
	static FString Regrow(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, bool debug, const UObject* WorldContextObject);
	
	UFUNCTION(BlueprintCallable, Category = GardenerToolkit)
	static FString InitializeFoliageTypes(UClass* foliageActorClassInput);	

private:

	static int UndeleteFoliage_New(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, FString& log, bool debug, UWorld* World);
	static AFoliageGhost* RespawnActor(UHierarchicalInstancedStaticMeshComponent* mesh, FVector location, FTransform transform, UWorld* World, FString& log, bool debug);
};

