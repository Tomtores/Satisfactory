#include "FoliageGhost.h"



void AFoliageGhost::SetupData(TPair<FName, FName> removalActorIdentifier, FTransform transform, AFGFoliageRemovalSubsystem* foliageSystem)
{
	this->mRemovalActorIdentifier = removalActorIdentifier;
	this->mTransform = transform;
	this->mFoliageSystem = foliageSystem;
}

bool AFoliageGhost::RemoveFromWorld(FString& log)
{
	if (!mFoliageSystem)
	{
		log += "Foliage subsystem missing!\n";
		return false;	
	}

	/*AFGFoliageRemoval* removalActor = mFoliageSystem->FindFoliageRemovalActor(mRemovalActorIdentifier.Get<0>(), mRemovalActorIdentifier.Get<1>());

	if (!removalActor)
	{
		log += "Failed to resolve removal actor!\n";
		return false;	
	}	

	log += "Removed instances before ";
    log.AppendInt(removalActor->mRemovedInstances.Items.Num());

	FRemovedInstance* instance = new FRemovedInstance();
	instance->Transform = mTransform;

	removalActor->mRemovedInstances.Items.Emplace(*instance);
	
	log += "Removed instances after ";
	log.AppendInt(removalActor->mRemovedInstances.Items.Num());*/

	return this->Destroy();
}