#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Containers/Map.h"
#include "Engine/World.h"
#include "Engine/EngineTypes.h"
#include "Engine/StaticMeshActor.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"

#include <FactoryGame/Public/FGFoliageRemovalSubsystem.h>

#include "FoliageGhost.h"
#include "URegrowCommand.generated.h"


UCLASS()
class GARDENERTOOLS_API URegrowCommand : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category=GardenerToolkit, meta = (WorldContext = "WorldContextObject"))
	static FString Regrow(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int rangeInMeters, bool debug, const UObject* WorldContextObject);
	
	UFUNCTION(BlueprintCallable, Category = GardenerToolkit)
	static int CountRemovals(AFGFoliageRemovalSubsystem* FoliageSystem, bool debug, FString& log);

	UFUNCTION(BlueprintCallable, Category = GardenerToolkit)
	static FString InitializeFoliageTypes(UClass* foliageActorClassInput);	

private:

	static int UndeleteFoliage_Update8(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, FString& log, bool debug, UWorld* World);
};

