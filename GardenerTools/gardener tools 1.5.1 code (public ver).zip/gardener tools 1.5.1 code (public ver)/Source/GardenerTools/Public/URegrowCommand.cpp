#include "URegrowCommand.h"

UClass* FoliageActorClass;
const int MaxBatchUndeletes = 1000;

static bool IsInRange(FVector foliageLocation, FVector playerLocation, int range, FString& log, bool debug)
{
	float distance = FVector::Dist(playerLocation, foliageLocation);

	if (debug)
	{
		log += FString::Printf(TEXT("Distance %d\n"), (int)distance);
	}

	return distance <= range;
}

FString URegrowCommand::InitializeFoliageTypes(UClass* foliageActorClassInput)
{
	FoliageActorClass = foliageActorClassInput;

	return FString("Cached foliage actor");
}

FString URegrowCommand::Regrow(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int rangeInMeters, bool debug, const UObject* WorldContextObject)
{
	if (!FoliageSystem)
	{
		return FString("Error! No subsystem");
	}
	if (!WorldContextObject)
	{
		return FString("Error, no World object!");
	}

	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

	if (!World)
	{
		return FString("Failed to resolve World object!");
	}

	FString result;
	int range = rangeInMeters * 100; // the internal UE calculations are in centimeters

	if (debug)
	{
		int countBefore = FoliageSystem->GetFoliageCountWithinRadius(playerLocation, range);

		result += FString::Printf(TEXT("Found %d total foliage items in the range.\n"), countBefore);		
	}

	int count = UndeleteFoliage_Update8(FoliageSystem, playerLocation, range, result, debug, World);

	result += FString::Printf(TEXT("Restored %d foliage items.\n"), count);

	if (debug)
	{
		int countAfter = FoliageSystem->GetFoliageCountWithinRadius(playerLocation, range);

		result += FString::Printf(TEXT("Found %d total foliage items in the range after operation"), countAfter);
	}

	return result;
}

int URegrowCommand::CountRemovals(AFGFoliageRemovalSubsystem* FoliageSystem, bool debug, FString& log)
{
	//return FoliageSystem->Stat_NumRemovedInstances(); //heh, doesnt work
	int deletedCount = 0;

	if (debug)
	{
		int tileCount = FoliageSystem->mSaveData.Num();
		log += FString::Printf(TEXT("Level tiles count: %d"), tileCount);
	}

	for (const TPair<FIntVector, FFoliageRemovalSaveDataPerCell>& level : FoliageSystem->mSaveData)	//iterate map squares
	{
		for (const TPair<const UFoliageType*, FFoliageRemovalSaveDataForFoliageType>& foliageTypes : level.Value.SaveDataMap)	// iterate foliage types
		{
			deletedCount += foliageTypes.Value.Locations().Num();
		}
	}

	return deletedCount;
};

AFoliageGhost* RespawnActor(const UHierarchicalInstancedStaticMeshComponent* mesh, FVector location, UWorld* World, FString& log, bool debug, 
	FIntVector levelChunkId, const UFoliageType* foliageTypeKey, uint32 hash, AFGFoliageRemovalSubsystem* FoliageSystem)
{
	FActorSpawnParameters parameters = FActorSpawnParameters();
	parameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	parameters.bNoFail = true;
	AFoliageGhost* RespawnedFoliage = World->SpawnActor<AFoliageGhost>(FoliageActorClass, location, location.Rotation(), parameters);

	if (RespawnedFoliage)
	{
		RespawnedFoliage->SetMobility(EComponentMobility::Stationary);
		UStaticMeshComponent* MeshComponent = RespawnedFoliage->GetStaticMeshComponent();
		if (MeshComponent)
		{
			MeshComponent->SetStaticMesh(mesh->GetStaticMesh());
		}
		else if (debug)
		{
			log += "Failed to get mesh component of spawned actor!!!\n";
		}

		RespawnedFoliage->SetupData(levelChunkId, foliageTypeKey, location, hash, FoliageSystem);
	}
	else if (debug)
	{
		log += "Actor spawn failed!!!\n";
	}

	return RespawnedFoliage;
}

int URegrowCommand::UndeleteFoliage_Update8(AFGFoliageRemovalSubsystem* FoliageSystem, FVector playerLocation, int range, FString& log, bool debug, UWorld* World)
{
	int undeletedCount = 0;

	for (TPair<FIntVector, FFoliageRemovalSaveDataPerCell>& level : FoliageSystem->mSaveData)	//iterate map squares
	{
		for (TPair<const UFoliageType*, FFoliageRemovalSaveDataForFoliageType>& foliageTypes : level.Value.SaveDataMap)	// iterate foliage types
		{
			for (int32 i = foliageTypes.Value.RemovedLocations.Num() - 1; i >= 0; i--)	//iterate specific removals
			{
				if (IsInRange(foliageTypes.Value.RemovedLocations[i], playerLocation, range, log, debug))
				{
					uint32 hash = AFGFoliageRemovalSubsystem::HashFoliageInstanceLocation(foliageTypes.Value.RemovedLocations[i]);

					if (debug)
					{
						log += FString::Printf(TEXT("Found foliage in range with hash %u \n"), hash);
					}

					AFoliageGhost* RespawnedFoliage = nullptr;
					UFoliageType* keyCopy = const_cast<UFoliageType*>(foliageTypes.Key);	//tbh, I have no idea what I'm doing here
					UHierarchicalInstancedStaticMeshComponent* const* mesh = FoliageSystem->mFoliageComponentTypeMapping.FindKey(keyCopy);
					if (mesh)
					{
						RespawnedFoliage = RespawnActor(*mesh, foliageTypes.Value.RemovedLocations[i], World, log, debug, level.Key, foliageTypes.Key, hash, FoliageSystem);						
					}					

					if (RespawnedFoliage)
					{
						foliageTypes.Value.RemovedLocations.RemoveAt(i);
						foliageTypes.Value.RemovedLocationLookup.Remove(hash);
					}
					else if (debug)
					{
						log += FString::Printf(TEXT("Null actor for respawned foliage with hash %u!\n"), hash);
					}					

					undeletedCount++;
					if (undeletedCount >= MaxBatchUndeletes)
					{
						return undeletedCount;
					}
				}
			}
		}
	}

	return undeletedCount;
}




